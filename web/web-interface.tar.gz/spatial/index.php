<html>
<head>
<title>Radiance Spatial Plots</title>

 <?php
  ini_set('display_errors', 'On');
 
  $datadir = 'spatial_data/';

  $insttable = array(
    "platform" => array(
      array("name" => "msu_tirosn",   "longname" => "MSU TIROS-N",    "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n06",      "longname" => "MSU NOAA-6",     "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n07",      "longname" => "MSU NOAA-7",     "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n08",      "longname" => "MSU NOAA-8",     "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n09",      "longname" => "MSU NOAA-9",     "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n10",      "longname" => "MSU NOAA-10",    "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n11",      "longname" => "MSU NOAA-11",    "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n12",      "longname" => "MSU NOAA-12",    "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "msu_n14",      "longname" => "MSU NOAA-14",    "nchan" => 4,   "startch" => 2,  "dosubset" => false),
      array("name" => "ssu_tirosn",   "longname" => "SSU TIROS-N",    "nchan" => 4,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssu_n06",      "longname" => "SSU NOAA-6",     "nchan" => 4,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssu_n07",      "longname" => "SSU NOAA-7",     "nchan" => 4,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssu_n08",      "longname" => "SSU NOAA-8",     "nchan" => 4,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssu_n09",      "longname" => "SSU NOAA-9",     "nchan" => 4,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssu_n11",      "longname" => "SSU NOAA-11",    "nchan" => 4,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssu_n14",      "longname" => "SSU NOAA-14",    "nchan" => 4,   "startch" => 1,  "dosubset" => false),
      array("name" => "amsua_n15",    "longname" => "AMSU-A NOAA-15", "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "amsua_n16",    "longname" => "AMSU-A NOAA-16", "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "amsua_n17",    "longname" => "AMSU-A NOAA-17", "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "amsua_n18",    "longname" => "AMSU-A NOAA-18", "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "amsua_n19",    "longname" => "AMSU-A NOAA-19", "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "amsua_metop-a","longname" => "AMSU-A METOP-A", "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "amsua_metop-b","longname" => "AMSU-A METOP-B", "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "amsua_aqua",   "longname" => "AMSU-A Aqua",    "nchan" => 15,  "startch" => 6,  "dosubset" => false),
      array("name" => "atms_npp",     "longname" => "ATMS SNPP",      "nchan" => 22,  "startch" => 6,  "dosubset" => false),
      array("name" => "hirs2_tirosn", "longname" => "HIRS2 TIROS-N",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n06",    "longname" => "HIRS2 NOAA-6",   "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n07",    "longname" => "HIRS2 NOAA-7",   "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n08",    "longname" => "HIRS2 NOAA-8",   "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n09",    "longname" => "HIRS2 NOAA-9",   "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n10",    "longname" => "HIRS2 NOAA-10",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n11",    "longname" => "HIRS2 NOAA-11",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n12",    "longname" => "HIRS2 NOAA-12",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs2_n14",    "longname" => "HIRS2 NOAA-14",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs3_n15",    "longname" => "HIRS3 NOAA-15",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs3_n16",    "longname" => "HIRS3 NOAA-16",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs3_n17",    "longname" => "HIRS3 NOAA-17",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs4_n18",    "longname" => "HIRS4 NOAA-18",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs4_n19",    "longname" => "HIRS4 NOAA-19",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs4_metop-a","longname" => "HIRS4 METOP-A",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "hirs4_metop-b","longname" => "HIRS4 METOP-B",  "nchan" => 19,  "startch" => 2,  "dosubset" => false),
      array("name" => "airs_aqua",    "longname" => "AIRS AQUA",      "nchan" => 281, "startch" => 3,  "dosubset" => false),
      array("name" => "iasi_metop-a", "longname" => "IASI METOP-A",   "nchan" => 616, "startch" => 1,  "dosubset" => false),
      array("name" => "iasi_metop-b", "longname" => "IASI METOP-B",   "nchan" => 616, "startch" => 1,  "dosubset" => false),
      array("name" => "cris_npp",     "longname" => "CRIS NPP",       "nchan" => 399, "startch" => 1,  "dosubset" => false),
      array("name" => "airscld_aqua",    "longname" => "AIRSCLD AQUA",      "nchan" => 281, "startch" => 3,  "dosubset" => false),
      array("name" => "iasicld_metop-a", "longname" => "IASICLD METOP-A",   "nchan" => 616, "startch" => 1,  "dosubset" => false),
      array("name" => "iasicld_metop-b", "longname" => "IASICLD METOP-B",   "nchan" => 616, "startch" => 1,  "dosubset" => false),
      array("name" => "criscld_npp",     "longname" => "CRISCLD NPP",       "nchan" => 399, "startch" => 1,  "dosubset" => false),
      array("name" => "ssmi_f08",     "longname" => "SSMI F08",       "nchan" => 7,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssmi_f10",     "longname" => "SSMI F10",       "nchan" => 7,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssmi_f11",     "longname" => "SSMI F11",       "nchan" => 7,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssmi_f13",     "longname" => "SSMI F13",       "nchan" => 7,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssmi_f14",     "longname" => "SSMI F14",       "nchan" => 7,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssmi_f15",     "longname" => "SSMI F15",       "nchan" => 7,   "startch" => 1,  "dosubset" => false),
      array("name" => "ssmis_f16",    "longname" => "SSMIS F16",      "nchan" => 24,  "startch" => 3,  "dosubset" => false),
      array("name" => "ssmis_f17",    "longname" => "SSMIS F17",      "nchan" => 24,  "startch" => 3,  "dosubset" => false),
      array("name" => "ssmis_f18",    "longname" => "SSMIS F18",      "nchan" => 24,  "startch" => 3,  "dosubset" => false),
      array("name" => "ssmis_f19",    "longname" => "SSMIS F19",      "nchan" => 24,  "startch" => 3,  "dosubset" => false),
      array("name" => "amsub_n15",    "longname" => "AMSU-B NOAA-15", "nchan" => 5,   "startch" => 1,  "dosubset" => false),
      array("name" => "amsub_n16",    "longname" => "AMSU-B NOAA-16", "nchan" => 5,   "startch" => 1,  "dosubset" => false),
      array("name" => "amsub_n17",    "longname" => "AMSU-B NOAA-17", "nchan" => 5,   "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd1_g13",   "longname" => "GOES-13 Sndr D1","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd2_g13",   "longname" => "GOES-13 Sndr D2","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd3_g13",   "longname" => "GOES-13 Sndr D3","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd4_g13",   "longname" => "GOES-13 Sndr D3","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd1_g15",   "longname" => "GOES-15 Sndr D1","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd2_g15",   "longname" => "GOES-15 Sndr D2","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd3_g15",   "longname" => "GOES-15 Sndr D3","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "sndrd4_g15",   "longname" => "GOES-15 Sndr D3","nchan" => 18,  "startch" => 1,  "dosubset" => false),
      array("name" => "mhs_n18",      "longname" => "MHS NOAA-18",    "nchan" => 5,   "startch" => 1,  "dosubset" => false),
      array("name" => "mhs_n19",      "longname" => "MHS NOAA-19",    "nchan" => 5,   "startch" => 1,  "dosubset" => false),
      array("name" => "mhs_metop-a",  "longname" => "MHS METOP-A",    "nchan" => 5,   "startch" => 1,  "dosubset" => false),
      array("name" => "mhs_metop-b",  "longname" => "MHS METOP-B",    "nchan" => 5,   "startch" => 1,  "dosubset" => false),
      array("name" => "avhrr_n18",    "longname" => "AVHRR NOAA-18",  "nchan" => 3,   "startch" => 1,  "dosubset" => false),
      array("name" => "avhrr_metop-a","longname" => "AVHRR Metop-A",  "nchan" => 3,   "startch" => 1,  "dosubset" => false),
      array("name" => "conv",         "longname" => "Conv by kx",     "nchan" => 999,   "startch" => 1,  "dosubset" => false),
      array("name" => "conv_04",      "longname" => "Conv-U Wind",    "nchan" => 999,   "startch" => 1,  "dosubset" => false),
      array("name" => "conv_05",      "longname" => "Conv-V Wind",    "nchan" => 999,   "startch" => 1,  "dosubset" => false),
      array("name" => "conv_11",      "longname" => "Conv-Spec. Hum", "nchan" => 999,   "startch" => 1,  "dosubset" => false),
      array("name" => "conv_33",      "longname" => "Conv-Sfc Pres",  "nchan" => 999,   "startch" => 1,  "dosubset" => false),
      array("name" => "conv_44",      "longname" => "Conv-Temp",      "nchan" => 999,   "startch" => 1,  "dosubset" => false),
      array("name" => "conv_89",      "longname" => "Conv-BendAngle", "nchan" => 999,   "startch" => 1,  "dosubset" => false),
      )
   );

   $cycletype = array(
      array("fn_abbr" => "all", "longname" => "All Cycles"),
      array("fn_abbr" => "00z", "longname" => "00z Only"),
      array("fn_abbr" => "06z", "longname" => "06z Only"),
      array("fn_abbr" => "12z", "longname" => "12z Only"),
      array("fn_abbr" => "18z", "longname" => "18z Only"),
   );

   $imgtype = array(
      array("fn_abbr" => "count",  "longname" => "Observation Count"),
      array("fn_abbr" => "omfbc",  "longname" => "Mean O-F w/ Bias Correction"),
      array("fn_abbr" => "omfnbc", "longname" => "Mean O-F w/o Bias Correction"),
      array("fn_abbr" => "sigo",   "longname" => "Mean Observation Error"),
      array("fn_abbr" => "prall",  "longname" => "Mean Total Bias Correction"),
      array("fn_abbr" => "pr1",    "longname" => "Mean Constant Correction"),
      array("fn_abbr" => "pr2",    "longname" => "Mean Fixed Position Correction"),
      array("fn_abbr" => "pr3",    "longname" => "Mean Variational ScanAng Correction"),
      array("fn_abbr" => "pr6",    "longname" => "Mean Cloud Liquid Water Correction"),
      array("fn_abbr" => "pr4",    "longname" => "Mean Lapse Rate Correction"),
      array("fn_abbr" => "pr5",    "longname" => "Mean Lapse Rate**2 Correction"),
      array("fn_abbr" => "prlapse","longname" => "Mean Total Lapse Rate Correction"),
      array("fn_abbr" => "imp",    "longname" => "Total Impact"),
      array("fn_abbr" => "imppo",  "longname" => "Impact per Ob"),
   );

   $explist = glob("$datadir/*",GLOB_ONLYDIR);                                      # Gather experiments
   usort($explist,create_function('$a,$b', 'return filemtime($a) - filemtime($b);'));  # sort by time
   $explist = array_reverse($explist);                                                 # reverse, so newest is first

   $explist = array_map('basename',$explist);

   if (! isset($_POST['exp1'])) {
      $_POST['exp1'] = $explist[0];
   } 

   if (! isset($_POST['exp2'])) {
      $_POST['exp2'] = "none";
   }


   if (! isset($_POST['imgtype'])) $_POST['imgtype'] = $imgtype[0]["fn_abbr"];
   if (! isset($_POST['cycletype'])) $_POST['cycletype'] = $cycletype[0]["fn_abbr"];

   $curexp1 = $_POST['exp1'];
   $curexp2 = $_POST['exp2'];

   $instlist = glob("$datadir/$curexp1/work/*",GLOB_ONLYDIR);
   if (! is_array($instlist)) $instlist = array($instlist);
   $instlist = array_map('basename',$instlist);

   if (! isset($_POST['inst'])) $_POST['inst'] = $instlist[0];
   if (! in_array($_POST['inst'],$instlist)) $_POST['inst'] = $instlist[0];
   $curinst = $_POST['inst'];

   foreach ($insttable["platform"] as $curplat) {
      if ($curplat['name'] == $curinst) {
         if (! isset($_POST['chan'])) $_POST['chan'] = $curplat['startch'];
         if ($_POST['chan'] > $curplat['nchan']) $_POST['chan'] = $curplat['startch'];
      }
   }
?>
</head>
<body>

<form action="index.php" method="post">

<table width=1030px >
<tr>
<td width=350px valign="top">
   <table cols=2 border=2 cellpadding=6 cellspacing=8 >
   <tr>
   <td>
      Experiment
   </td>
   <td>
      Comparison
   </td>
   </tr>
   <tr>
   <td>
      <select name="exp1" style="width:100%" onchange="this.form.submit();">
      <?php
         foreach ($explist as $exp) {
            if ($curexp1 == $exp) {
               echo "  <option value={$exp} selected>{$exp}</option>\n";
            } else {
               echo "  <option value={$exp}>{$exp}</option>\n";
            }
         }
      ?>
      </select>
   </td>
   <td>
      <select name="exp2" style="width:100%" onchange="this.form.submit();">
      <?php
         if ($curexp2 == "none") {
            echo "  <option value=None selected>None</option>\n";
         } else {
            echo "  <option value=None>None</option>\n";
         }
         foreach ($explist as $exp) {
            if ($curexp2 == $exp) {
               echo "  <option value={$exp} selected>{$exp}</option>\n";
            } else {
               echo "  <option value={$exp}>{$exp}</option>\n";
            }
         }
      ?>
      </select>
   </td>
   </tr>
   <tr>
   <td>
      <select name="inst" style="width:100%" onchange="this.form.submit();">
      <?php
         $instsel = false;
         foreach ($instlist as $inst) {
            $instmatch = false;
            foreach ($insttable["platform"] as $curplat) {
               if ($inst == $curplat['name']) {
                  $instmatch = true;
                  if ($curinst == $inst) {
                     echo "  <option value={$curplat['name']} selected>{$curplat['longname']}</option>\n";
                     $nchan    = $curplat['nchan'];
                     $dosubset = $curplat['dosubset'];
                     $instsel = true;
                  } else {
                     echo "  <option value={$curplat['name']}>{$curplat['longname']}</option>\n";
                  };
               };
            };
            if (! $instmatch) echo "<br><br><br>WARNING: $inst not matched in table!!!<br><br><br>\n";
         };
         if (! $instsel) {
            $curinst = $instlist[0];
            foreach ($insttable["platform"] as $curplat) {
               if ($curinst == $curplat['name']) {
                  $nchan    = $curplat['nchan'];
                  $dosubset = $curplat['dosubset'];
                  $instsel = true;
               }
            }
         };
      ?>
      </select>
   </td>
   <td>   
      <select name="chan" style="width:100%" onchange="this.form.submit();">
      <?php
         foreach (range(1, $nchan) as $chan) {
            $img = "{$datadir}/{$_POST['exp1']}/work/{$_POST['inst']}/{$_POST['inst']}.all.agg.$chan.count.png";
            echo "$img<br>";
            if (file_exists($img)) {     
               if ($_POST['chan'] == $chan) {
                  echo "  <option value=$chan selected> Ch. $chan </option>\n";
               } else {
                  echo "  <option value=$chan > Ch. $chan </option>\n";
               }
            }
         }
      ?>
      </select>
   </td>
   </tr>
   <tr>
   <td colspan=2>   
      <select name="imgtype" style="width:100%" onchange="this.form.submit();">
      <?php
         foreach ($imgtype as $ctype) {
            if ($_POST['imgtype'] == $ctype["fn_abbr"]) {
               echo "  <option value={$ctype["fn_abbr"]} selected> {$ctype["longname"]} </option>\n";
            } else {
               echo "  <option value={$ctype["fn_abbr"]}> {$ctype["longname"]} </option>\n";
            }
         }
      ?>
      </select>
   </td>
   </tr>
   <tr>  
   <td colspan=2>
      <select name="cycletype" style="width:100%" onchange="this.form.submit();">
      <?php
         foreach ($cycletype as $ctype) {
            if ($_POST['cycletype'] == $ctype["fn_abbr"]) {
               echo "  <option value={$ctype["fn_abbr"]} selected> {$ctype["longname"]} </option>\n";
            } else {
               echo "  <option value={$ctype["fn_abbr"]}> {$ctype["longname"]} </option>\n";
            }
         }
      ?>
      </select>
   </td>

   <tr>
      <td colspan=2>
        <center>
          <?php
            echo "<img src=\"/products/nwp/systems/radmon/wf/{$_POST['inst']}/wf_{$_POST['inst']}_chan{$_POST['chan']}.png\">\n";
          ?>
        </center>
      </td>
   </tr>

   </tr>
   </table>   
</td>   
<td width=700px valign="top">   
   <table width=100%>
   <tr>
   <td>
      <?php
         echo "<center>{$_POST['exp1']}</center>\n";
         $img = "{$datadir}{$_POST['exp1']}/work/{$_POST['inst']}/{$_POST['inst']}.{$_POST['cycletype']}.agg.{$_POST['chan']}.{$_POST['imgtype']}.png";
         echo "<a href=\"$img\"> \n";
         echo "<img src=\"$img\">\n";
         echo "</a>\n";
      ?>
   </td>
   </tr>
   <tr>
   <td>
      <?php
         $img = "{$datadir}{$_POST['exp2']}/work/{$_POST['inst']}/{$_POST['inst']}.{$_POST['cycletype']}.agg.{$_POST['chan']}.{$_POST['imgtype']}.png";
         if (file_exists($img)) {
            echo "<center>{$_POST['exp2']}</center>\n";
            echo "<a href=\"$img\"> \n";
            echo "<img src=\"$img\">\n";
            echo "</a>\n";
         }
      ?>
   </td>
   </tr>
   <tr>
   <td>
      <?php
         $img = "{$datadir}{$_POST['exp1']}/diff-{$_POST['exp2']}/{$_POST['inst']}/{$_POST['inst']}.{$_POST['cycletype']}.agg.{$_POST['chan']}.{$_POST['imgtype']}.png";
         if (file_exists($img)) {
            echo "<center>{$_POST['exp1']} - {$_POST['exp2']}</center>\n";
            echo "<a href=\"$img\"> \n";
            echo "<img src=\"$img\">\n";
            echo "</a>\n";
         }
      ?>
   </td>
   </tr>

</td>
</tr>
</table>   

</body></html>

